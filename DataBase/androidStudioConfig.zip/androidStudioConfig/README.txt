Accesos directos
	Modificar rutas de archivos dentro de carpeta usr y mover a carpeta raíz del sistema

Esquema de colores y configuración de teclas
	Desde Android Studio importar preferencias "settingsAndroidStudio.jar"
